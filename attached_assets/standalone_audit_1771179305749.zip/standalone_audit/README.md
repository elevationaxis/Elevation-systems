# Standalone Brand Guardian Audit Tool

This is a simplified, standalone version of the Brand Guardian audit page that can be easily integrated into any React project (including Replit).

## Files Included

1. **AuditPage.tsx** - Frontend React component with the audit form and results display
2. **auditAPI.ts** - Backend API handler for running audits
3. **README.md** - This file

## Features

- **4-Module Audit System**:
  1. Technical Truth (Schema Analysis)
  2. Knowledge Base (Directory Sync)
  3. Live Reputation (Sentiment Analysis)
  4. AI Visibility Test (Real-time AI Query)

- **Visual Score Display**: Circular gauge showing overall AI readiness score
- **Real-time Polling**: Automatically polls for results while audit is processing
- **Recommendations**: Actionable suggestions based on audit findings

## Setup Instructions

### Frontend (React)

1. Copy `AuditPage.tsx` to your React project
2. Install required dependencies:
   ```bash
   npm install lucide-react
   ```

3. Import and use the component:
   ```tsx
   import AuditPage from './AuditPage';
   
   function App() {
     return <AuditPage />;
   }
   ```

4. Add Tailwind CSS classes (the component uses Tailwind for styling)

### Backend (Node.js)

1. Copy `auditAPI.ts` to your backend
2. Install required dependencies:
   ```bash
   npm install openai  # or your preferred LLM provider
   ```

3. **IMPORTANT**: Configure your LLM API:
   - Open `auditAPI.ts`
   - Uncomment the `callLLM` function
   - Add your OpenAI API key (or integrate with another LLM provider)

4. Set up API routes:

   **For Express.js:**
   ```typescript
   import express from 'express';
   import { createAudit, getAudit } from './auditAPI';
   
   const app = express();
   app.use(express.json());
   
   app.post('/api/audit/create', async (req, res) => {
     const { businessName, websiteUrl } = req.body;
     const result = await createAudit({ businessName, websiteUrl });
     res.json(result);
   });
   
   app.get('/api/audit/:auditId', (req, res) => {
     const auditId = parseInt(req.params.auditId);
     const audit = getAudit(auditId);
     res.json(audit || { error: 'Not found' });
   });
   ```

   **For Next.js API Routes:**
   ```typescript
   // pages/api/audit/create.ts
   import { createAudit } from '@/lib/auditAPI';
   
   export default async function handler(req, res) {
     if (req.method === 'POST') {
       const result = await createAudit(req.body);
       res.json(result);
     }
   }
   
   // pages/api/audit/[auditId].ts
   import { getAudit } from '@/lib/auditAPI';
   
   export default function handler(req, res) {
     const auditId = parseInt(req.query.auditId);
     const audit = getAudit(auditId);
     res.json(audit || { error: 'Not found' });
   }
   ```

## Database Integration (Optional)

The current implementation uses in-memory storage. For production, replace the `Map` with a database:

```typescript
// Example with Prisma
const audit = await prisma.audit.create({
  data: {
    businessName: input.businessName,
    websiteUrl: input.websiteUrl,
    status: "processing",
  }
});
```

## Customization

### Change Colors
The component uses purple/amber gradient. To change:
- Search for `purple` and `amber` in `AuditPage.tsx`
- Replace with your brand colors (e.g., `blue`, `green`)

### Modify Scoring Logic
Edit the `runAudit` function in `auditAPI.ts` to adjust:
- Scoring thresholds
- Module weights
- Recommendation triggers

### Add More Modules
To add additional audit modules:
1. Add module to `AuditResult` type
2. Add analysis step in `runAudit` function
3. Add display card in `AuditPage.tsx`

## Environment Variables

Create a `.env` file:
```
OPENAI_API_KEY=your_api_key_here
# or
ANTHROPIC_API_KEY=your_api_key_here
```

## Limitations

This standalone version:
- **Does NOT crawl actual websites** - it uses LLM estimates based on domain names
- **Uses in-memory storage** - audits are lost on server restart
- **No PDF export** - the original version has jsPDF integration (can be added)
- **No database** - you'll need to add persistence for production

## Production Checklist

Before deploying to production:

- [ ] Add database integration (PostgreSQL, MySQL, etc.)
- [ ] Implement proper error handling
- [ ] Add rate limiting to prevent abuse
- [ ] Set up monitoring and logging
- [ ] Add authentication if needed
- [ ] Implement PDF export (using jsPDF)
- [ ] Add email notifications for completed audits
- [ ] Set up proper CORS configuration
- [ ] Add input validation and sanitization
- [ ] Configure environment variables properly

## Support

For questions or issues:
- Review the original implementation in `/home/ubuntu/elevation-axis-audit`
- Check the tRPC router at `server/routers.ts` for the full audit logic
- See `server/auditEngine.ts` for the complete audit engine

## License

This code is provided as-is for your use in the Elevation Systems project.
