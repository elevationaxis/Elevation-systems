// Standalone Brand Guardian Audit Page
// This is a simplified version that can be copied to Replit

import { useState } from "react";
import { Loader2, Shield, CheckCircle2, XCircle, AlertCircle, Download } from "lucide-react";

// Types
interface AuditResult {
  auditId: number;
  businessName: string;
  websiteUrl: string;
  status: "pending" | "processing" | "complete" | "failed";
  overallScore: number | null;
  modules: {
    schema: {
      score: number | null;
      status: "specific" | "generic" | "missing" | null;
    };
    directory: {
      score: number | null;
    };
    sentiment: {
      score: "positive" | "mixed" | "negative" | null;
    };
    aiVisibility: {
      score: number | null;
    };
  };
  recommendations: string[];
}

export default function AuditPage() {
  const [businessName, setBusinessName] = useState("");
  const [websiteUrl, setWebsiteUrl] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [auditResult, setAuditResult] = useState<AuditResult | null>(null);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      // Replace with your actual API endpoint
      const response = await fetch("/api/audit/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ businessName, websiteUrl }),
      });
      
      const data = await response.json();
      
      // Poll for results
      pollForResults(data.auditId);
    } catch (error) {
      console.error("Error creating audit:", error);
      setIsSubmitting(false);
    }
  };
  
  const pollForResults = async (auditId: number) => {
    const interval = setInterval(async () => {
      try {
        const response = await fetch(`/api/audit/${auditId}`);
        const data = await response.json();
        
        if (data.status === "complete" || data.status === "failed") {
          clearInterval(interval);
          setAuditResult(data);
          setIsSubmitting(false);
        }
      } catch (error) {
        console.error("Error polling audit:", error);
        clearInterval(interval);
        setIsSubmitting(false);
      }
    }, 2000);
  };
  
  const getScoreColor = (score: number | null | undefined) => {
    if (!score) return "text-gray-400";
    if (score >= 75) return "text-green-500";
    if (score >= 50) return "text-yellow-500";
    return "text-red-500";
  };
  
  const getStatusIcon = (status: string | null | undefined) => {
    if (status === "visible" || status === "specific" || status === "positive") {
      return <CheckCircle2 className="w-6 h-6 text-green-500" />;
    }
    if (status === "generic" || status === "mixed") {
      return <AlertCircle className="w-6 h-6 text-yellow-500" />;
    }
    return <XCircle className="w-6 h-6 text-red-500" />;
  };
  
  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Hero Section */}
      <section className="pt-32 pb-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-purple-500/10 border border-purple-500/20 rounded-full px-4 py-2 mb-6">
            <Shield className="w-4 h-4 text-purple-400" />
            <span className="text-sm text-purple-300">Free Visibility Audit</span>
          </div>
          
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-white via-purple-200 to-amber-300 bg-clip-text text-transparent">
            Brand Guardian Audit
          </h1>
          
          <p className="text-xl text-slate-400 mb-12 max-w-2xl mx-auto">
            Find out if your business is invisible to search engines. Get your free 4-module visibility scorecard in minutes.
          </p>
        </div>
        
        {/* Audit Form or Results */}
        {!auditResult ? (
          <div className="max-w-2xl mx-auto p-8 bg-slate-900/50 border border-slate-800 rounded-lg">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="businessName" className="block text-sm font-medium text-slate-200 mb-2">
                  Business Name
                </label>
                <input
                  id="businessName"
                  type="text"
                  placeholder="e.g., OnePoint Heating & Cooling"
                  value={businessName}
                  onChange={(e) => setBusinessName(e.target.value)}
                  required
                  className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
              
              <div>
                <label htmlFor="websiteUrl" className="block text-sm font-medium text-slate-200 mb-2">
                  Website URL
                </label>
                <input
                  id="websiteUrl"
                  type="url"
                  placeholder="e.g., https://onepointheating.com"
                  value={websiteUrl}
                  onChange={(e) => setWebsiteUrl(e.target.value)}
                  required
                  className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
              
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full px-6 py-3 bg-gradient-to-r from-purple-600 to-amber-500 hover:from-purple-700 hover:to-amber-600 rounded-lg font-medium transition-all disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin inline" />
                    Analyzing Your Business...
                  </>
                ) : (
                  "Get Your Free Audit"
                )}
              </button>
            </form>
          </div>
        ) : (
          <div className="max-w-5xl mx-auto space-y-8">
            {/* Overall Score Gauge */}
            <div className="p-8 bg-slate-900/50 border border-slate-800 rounded-lg">
              <div className="text-center">
                <h2 className="text-3xl font-bold text-white mb-4">AI Readiness Score</h2>
                <div className="relative inline-flex items-center justify-center w-48 h-48">
                  <svg className="w-full h-full transform -rotate-90">
                    <circle
                      cx="96"
                      cy="96"
                      r="88"
                      stroke="currentColor"
                      strokeWidth="12"
                      fill="none"
                      className="text-slate-800"
                    />
                    <circle
                      cx="96"
                      cy="96"
                      r="88"
                      stroke="currentColor"
                      strokeWidth="12"
                      fill="none"
                      strokeDasharray={`${2 * Math.PI * 88}`}
                      strokeDashoffset={`${2 * Math.PI * 88 * (1 - (auditResult.overallScore || 0) / 100)}`}
                      className={auditResult.overallScore && auditResult.overallScore >= 75 ? "text-green-500" : auditResult.overallScore && auditResult.overallScore >= 50 ? "text-yellow-500" : "text-red-500"}
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className={`text-5xl font-bold ${getScoreColor(auditResult.overallScore)}`}>
                        {auditResult.overallScore || 0}
                      </div>
                      <div className="text-sm text-slate-400">out of 100</div>
                    </div>
                  </div>
                </div>
                <p className="mt-6 text-slate-300">
                  {auditResult.overallScore && auditResult.overallScore >= 75
                    ? "Excellent! Your business is AI-ready."
                    : auditResult.overallScore && auditResult.overallScore >= 50
                    ? "Good start, but there's room for improvement."
                    : "Your business is invisible to AI search engines."}
                </p>
              </div>
            </div>
            
            {/* 4 Module Results */}
            <div className="grid md:grid-cols-2 gap-6">
              {/* Module 1: Technical Truth */}
              <div className="p-6 bg-slate-900/50 border border-slate-800 rounded-lg">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-white">Technical Truth</h3>
                    <p className="text-sm text-slate-400">Schema Analysis</p>
                  </div>
                  {getStatusIcon(auditResult.modules.schema.status)}
                </div>
                <div className={`text-4xl font-bold mb-2 ${getScoreColor(auditResult.modules.schema.score)}`}>
                  {auditResult.modules.schema.score || 0}/100
                </div>
                <p className="text-slate-300 text-sm">
                  {auditResult.modules.schema.status === "specific"
                    ? "Your website speaks robot language perfectly!"
                    : auditResult.modules.schema.status === "generic"
                    ? "You have schema, but it's missing key details."
                    : "No structured data found. AI can't read your site."}
                </p>
              </div>
              
              {/* Module 2: Knowledge Base */}
              <div className="p-6 bg-slate-900/50 border border-slate-800 rounded-lg">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-white">Knowledge Base</h3>
                    <p className="text-sm text-slate-400">Directory Sync</p>
                  </div>
                  {getStatusIcon(auditResult.modules.directory.score && auditResult.modules.directory.score >= 75 ? "visible" : "invisible")}
                </div>
                <div className={`text-4xl font-bold mb-2 ${getScoreColor(auditResult.modules.directory.score)}`}>
                  {auditResult.modules.directory.score || 0}/100
                </div>
                <p className="text-slate-300 text-sm">
                  {auditResult.modules.directory.score && auditResult.modules.directory.score >= 75
                    ? "Your NAP is consistent across all directories."
                    : "Inconsistent business info across Google, Bing, Apple Maps."}
                </p>
              </div>
              
              {/* Module 3: Live Reputation */}
              <div className="p-6 bg-slate-900/50 border border-slate-800 rounded-lg">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-white">Live Reputation</h3>
                    <p className="text-sm text-slate-400">Sentiment Analysis</p>
                  </div>
                  {getStatusIcon(auditResult.modules.sentiment.score)}
                </div>
                <div className="mb-2">
                  <span className={`text-2xl font-bold ${
                    auditResult.modules.sentiment.score === "positive" ? "text-green-500" :
                    auditResult.modules.sentiment.score === "mixed" ? "text-yellow-500" :
                    "text-red-500"
                  }`}>
                    {auditResult.modules.sentiment.score?.toUpperCase() || "UNKNOWN"}
                  </span>
                </div>
                <p className="text-slate-300 text-sm">
                  {auditResult.modules.sentiment.score === "positive"
                    ? "Your reviews are overwhelmingly positive."
                    : auditResult.modules.sentiment.score === "mixed"
                    ? "Mixed reviews may hurt AI recommendations."
                    : "Negative sentiment detected. Address this immediately."}
                </p>
              </div>
              
              {/* Module 4: AI Visibility Test */}
              <div className="p-6 bg-slate-900/50 border border-slate-800 rounded-lg">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-white">AI Visibility Test</h3>
                    <p className="text-sm text-slate-400">Real-time AI Query</p>
                  </div>
                  {getStatusIcon(auditResult.modules.aiVisibility.score && auditResult.modules.aiVisibility.score >= 75 ? "visible" : "invisible")}
                </div>
                <div className={`text-4xl font-bold mb-2 ${getScoreColor(auditResult.modules.aiVisibility.score)}`}>
                  {auditResult.modules.aiVisibility.score || 0}/100
                </div>
                <p className="text-slate-300 text-sm">
                  {auditResult.modules.aiVisibility.score && auditResult.modules.aiVisibility.score >= 75
                    ? "Your business appears in AI search results!"
                    : "Your business is invisible to AI search engines."}
                </p>
              </div>
            </div>
            
            {/* Recommendations */}
            {auditResult.recommendations && auditResult.recommendations.length > 0 && (
              <div className="p-8 bg-slate-900/50 border border-slate-800 rounded-lg">
                <h3 className="text-2xl font-bold text-white mb-6">Recommended Actions</h3>
                <div className="space-y-4">
                  {auditResult.recommendations.map((rec, index) => (
                    <div key={index} className="flex items-start gap-3 p-4 bg-slate-800/50 rounded-lg">
                      <AlertCircle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                      <p className="text-slate-300">{rec}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {/* CTA */}
            <div className="text-center p-8 bg-gradient-to-r from-purple-900/30 to-amber-900/30 border border-purple-500/20 rounded-lg">
              <h3 className="text-2xl font-bold text-white mb-4">
                Ready to Fix Your Visibility?
              </h3>
              <p className="text-slate-300 mb-6">
                Let's build your Brand Guardian infrastructure and get you visible to AI search engines.
              </p>
              <button className="px-8 py-3 bg-gradient-to-r from-purple-600 to-amber-500 hover:from-purple-700 hover:to-amber-600 rounded-lg font-medium transition-all">
                Book a Strategy Call
              </button>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
